#ifndef TREE_VERIFIER_H
#define TREE_VERIFIER_H

#include "file_reader.h"

bool verify_tree(square_graph *graph);


#endif /* TREE_VERIFIER_H */

